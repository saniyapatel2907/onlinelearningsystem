package com.onlinelearningsystem.OnlineLearningSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineLearningSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
